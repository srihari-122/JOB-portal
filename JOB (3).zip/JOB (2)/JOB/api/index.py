from main import app as fastapi_app

app = fastapi_app

